function[out]=mux_4by1_a(s1,s0,d0,d1,d2,d3)
if s1 <= 1 && s0 <= 1 && d0 <=1 && d1 <= 1&& d2 <= 1&& d3 <= 1
    a=not_a(s0);
    b=not_a(s1);
    c=and_a(a,b);
    d=and_a(c,d0);
    e=and_a(b,s0);
    f=and_a(e,d1);
    g=and_a(a,s0);
    h=and_a(g,d2);
    i=and_a(s1,s0);
    j=and_a(i,d3);
    k=or_a(d,f);
    l=or_a(h,j);
    out=or_a(k,l)
else
    fprintf("entered values are invalid! enter 0 or 1")
end
end