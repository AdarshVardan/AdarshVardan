function [out]=xor_a(a,b)
c=not_a(b);
d=and_a(a,c);
e=not_a(a);
f=and_a(e,b);
out=or_a(d,f);
end