function [out]= and_a(a,b)
if a==0&b==0
    out=0;
elseif a==0&b==1
    out=0;
elseif a==1&b==0
    out=0;
elseif a==1&b==1
    out=1;
else
    disp('not valid');
end
end