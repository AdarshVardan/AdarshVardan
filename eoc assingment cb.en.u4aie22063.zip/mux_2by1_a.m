function [out]=mux_2by1_a(S,D0,D1)
if S<=1&& D0 <=1 && d1 <= 1
a=not_a(s1);
b=and_a(a,d0);
c=and_a(d1,s1);
out=or_a(b,c)
else 
    disp("entered values are invalid!");
end
end