function z = demux_4by1_a(in,S0,S1)
if in<=1 && S0<=1 && S1<=1
    m=not_a(S0);
n=not_a(S1);
a=and_a(n,m);
F0=and_a(a,in);
b=and_a(n,S0);
F1=and_a(b,in);
c=and_a(S1,m);
F2=and_a(c,in);
e=and_a(S1,S0);
F3=and(e,in);
    z = [F0 F1 F2 F3];
else
    fprintf("entered values are invalid")
end
end