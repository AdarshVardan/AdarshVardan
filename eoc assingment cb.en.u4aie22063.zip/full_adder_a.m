function z = full_adder_a(a,b,c)  
if a<=1&&b<=1&&c<=1
d=not_a(b);
e=and_a(a,d);
f=not_a(a);
h=and_a(f,b);
i=or_a(e,g);
j=not_a(i);
k=and_a(j,c);
m=not_a(c);
n=and_a(m,h);
o=and_a(a,b);
p=and_a(a,c);
q=and_a(b,c);
r=or_a(o,p);
sum=or_a(k,n)
carry=or_a(r,q)
z=[sum,carry];
else
    fprintf("entered values are invalid!")
end
end