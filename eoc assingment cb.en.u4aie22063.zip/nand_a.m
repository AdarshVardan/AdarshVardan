function [out]=nand_a(a,b)
c=and_a(a,b);
out=not_a(c);
end