function z = half_adder(a,b)
if a<=1&&b<=1
c=not_a(a);
d=and_a(b,c);
e=not_a(b);
f=and_a(a,e);
sum=or_a(d,f)
carry=and_a(a,b)
z=[sum,carry];
else
    fprintf("entered values are invalid!")
end
end