function [out]=not_a(a)
if a==1
    out=0;
elseif a==0
    out=1;
else
    disp('not valid')
end
end