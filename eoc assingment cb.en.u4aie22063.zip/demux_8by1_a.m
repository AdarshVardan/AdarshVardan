function z = demux_8by1_a(in,S0,S1,S2)
if in<=1 && S0<=1 && S1<=1 && S2<=1
    x = not_a(S0);
    y = not_a(S1);
    z = not_(S2);
    F0 = and_a(andgate(in,x),and_gate(y,z));
    F1 = and_a(andgate(in,x),and_gate(y,S2));
    F2 = and_a(andgate(in,x),and_gate(S1,z));
    F3 = and_a(andgate(in,x),and_gate(S1,S2));
    F4 = and_a(andgate(in,S0),and_gate(y,z));
    F5 = and_a(andgate(in,S0),and_gate(y,S2));
    F6 = and_a(andgate(in,S0),and_gate(S1,z));
    F7 = and_a(andgate(in,S0),and_gate(S1,S2));
    z = [F0 F1 F2 F3 F4 F5 F6 F7];
else 
    fprintf("entered values are invalid")
end
end