function [out]=xnor_a(a,b)
c=not_a(a);
d=and_a(c,b);
e=not_a(b);
f=and_a(e,a);
g=or_a(d,f);
out=not_a(g);
end
