function z = demux_2by1_a(in,s0)
if in <= 1 && s0 <= 1
    c=not_a(s0);
    a=and_a(in,c);
    b=and_a(in,s0);
    z=[a b];
else 
    fprintf("entered values are invalid")
end
end
